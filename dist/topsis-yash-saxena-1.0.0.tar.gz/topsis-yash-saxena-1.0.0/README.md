Topsis
A Python pip package to apply topsis approach to rank the entries of a dataset based on different attributes.

Usage
$python <programName> <dataset> <weights array> <impacts array>

Example
$python programName.py data.csv '1,1,1,1' '+,+,-,+'